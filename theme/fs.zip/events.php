<?php
/**
 * Template Name: Events Page
 */
get_header(); 

?> 
