<footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Dr. Faustus. All rights reserved.</p>
            <p><a href="<?php echo home_url('/privacy-policy'); ?>">Privacy Policy</a></p>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>
