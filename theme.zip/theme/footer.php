    <div class="container">
        <p>© 2024 Dr Faustus GmbH. All rights reserved.</p>
        <p>
            <a href="/impressum">Impressum</a> | 
            <a href="/datenschutz">Datenschutz</a> 
        </p>
    </div>

<?php wp_footer(); ?>
